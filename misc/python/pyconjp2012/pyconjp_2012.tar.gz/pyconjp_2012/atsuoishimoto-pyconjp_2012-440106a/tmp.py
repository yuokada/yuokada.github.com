#!/usr/bin/env python2.7
import datetime

dt = datetime.datetime.today()
print dt
